package com.genshin.geniusinvocationtmg

enum class GameMode {
    FOUR_BY_THREE,FOUR_BY_FIVE,SIX_BY_SIX
}