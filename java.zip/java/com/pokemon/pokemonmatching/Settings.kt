package com.genshin.geniusinvocationtmg

import android.content.Context
import android.content.Context.MODE_PRIVATE


class Settings(val context: Context) {
    private val APP_SHARED_PREF = "AppSharedPref"
    private val SELECTED_GAME_MODE_KEY = "SelectedGameModeKey"
    private val sharedPreferences = context.getSharedPreferences(APP_SHARED_PREF, MODE_PRIVATE)

    fun setGameMode(selectedGameMode: GameMode) {
        val myEdit = sharedPreferences.edit()
        myEdit.putString(SELECTED_GAME_MODE_KEY, selectedGameMode.name)
        myEdit.apply()
    }

    fun getGameMode(): GameMode = GameMode.valueOf(
        sharedPreferences.getString(
            SELECTED_GAME_MODE_KEY,
            GameMode.FOUR_BY_THREE.name
        ) ?: GameMode.FOUR_BY_THREE.name
    )


}


