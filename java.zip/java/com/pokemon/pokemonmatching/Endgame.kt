package com.genshin.geniusinvocationtmg

import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.ActionBar
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.genshin.geniusinvocationtmg.GameMode.*
import com.genshin.geniusinvocationtmg.databinding.ActivityEndgameBinding
import kotlin.system.exitProcess

private lateinit var binding: ActivityEndgameBinding
private lateinit var intent: Intent

class Endgame : AppCompatActivity() {
    private val gameSettings by lazy {
        Settings(this)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemUi()
        }
    }

    private fun hideSystemUi() {
        val decorView = window.decorView
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEndgameBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val actionBar: ActionBar? = supportActionBar
        if (actionBar != null) {
            actionBar.hide()
        }

        val backgroundMediaPlayer = MediaPlayer.create(this, R.raw.tgm_eg_bgm)
        backgroundMediaPlayer.isLooping = true
        backgroundMediaPlayer.start()

        binding.egPlayagain.setOnClickListener {
            when (gameSettings.getGameMode()) {
                FOUR_BY_THREE -> start4x3Mode()
                FOUR_BY_FIVE -> start4x5Mode()
                SIX_BY_SIX -> start6x6Mode()
            }
        }

        binding.egHome.setOnClickListener {
            intent = Intent(this@Endgame, HomeMenu::class.java)
            backgroundMediaPlayer.release()
            this.finish()
            startActivity(intent)
        }

        binding.egExit.setOnClickListener() {
            exitProcess(0)
        }
    }

    private fun start4x3Mode() {
        val intent = Intent(this, MatchingGame::class.java)
        this.finish()
        startActivity(intent)
    }

    private fun start4x5Mode() {
        val intent = Intent(this, MatchingGame4x5::class.java)
        this.finish()
        startActivity(intent)
    }

    private fun start6x6Mode() {
        val intent = Intent(this, MatchingGame6x6::class.java)
        this.finish()
        startActivity(intent)
    }
}