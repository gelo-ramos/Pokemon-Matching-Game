package com.genshin.geniusinvocationtmg

import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.genshin.geniusinvocationtmg.databinding.ActivityHomeMenuBinding
import kotlin.system.exitProcess

private lateinit var binding: ActivityHomeMenuBinding


class HomeMenu : AppCompatActivity() {
    private val gameSettings by lazy {
        Settings(this)
    }


    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemUi()
        }
    }

    private fun hideSystemUi() {
        val decorView = window.decorView
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeMenuBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val actionBar: ActionBar? = supportActionBar
        if (actionBar != null) {
            actionBar.hide()
        }

        val backgroundMediaPlayer = MediaPlayer.create(this, R.raw.tgm_bgm)
        backgroundMediaPlayer.isLooping = true
        backgroundMediaPlayer.start()

        binding.btPlay.setOnClickListener {

            val selectedGameMode = binding.rgGameModes.checkedRadioButtonId

            when (selectedGameMode) {
                R.id.rb4by3 -> start4x3Mode()
                R.id.rb4by5 -> start4x5Mode()
                R.id.rb6by6 -> start6x6Mode()
                else -> start4x3Mode()
            }

            backgroundMediaPlayer.release()
        }

        binding.btExit.setOnClickListener {
            exitProcess(0)
        }
    }

    private fun start4x3Mode() {
        val intent = Intent(this, MatchingGame::class.java)
        this.finish()
        startActivity(intent)
        gameSettings.setGameMode(GameMode.FOUR_BY_THREE)
    }

    private fun start4x5Mode() {
        val intent = Intent(this, MatchingGame4x5::class.java)
        this.finish()
        startActivity(intent)
        gameSettings.setGameMode(GameMode.FOUR_BY_FIVE)
    }

    private fun start6x6Mode() {
        val intent = Intent(this, MatchingGame6x6::class.java)
        this.finish()
        startActivity(intent)
        gameSettings.setGameMode(GameMode.SIX_BY_SIX)
    }

}