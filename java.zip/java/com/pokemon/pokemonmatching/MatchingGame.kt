package com.genshin.geniusinvocationtmg

import android.content.Intent
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.genshin.geniusinvocationtmg.databinding.ActivityMatchingGameBinding
import edu.stanford.rkpandey.memorygame.MemoryCard


private const val TAG = "MatchingGame"
private lateinit var binding: ActivityMatchingGameBinding


class MatchingGame : AppCompatActivity() {
    private lateinit var buttons: List<ImageButton>
    private lateinit var cards: List<MemoryCard>
    private var indexOfSingleSelectedCard: Int? = null
    private lateinit var score: TextView
    private lateinit var time: TextView
    private lateinit var soundPool: SoundPool
    private var soundCue1: Int = 0
    private var soundCue2: Int = 0
    private var soundCue3: Int = 0

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemUi()
        }
    }

    private fun hideSystemUi() {
        val decorView = window.decorView
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMatchingGameBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val actionBar: ActionBar? = supportActionBar
        if (actionBar != null) {
            actionBar.hide()
        }

        score = findViewById(R.id.score)
        time = findViewById(R.id.time)

        placeDeck()

        soundPool = SoundPool.Builder()
            .setMaxStreams(10)
            .build()
        soundCue1 = soundPool.load(this, R.raw.match, 1)
        soundCue2 = soundPool.load(this, R.raw.not_match, 1)
        soundCue3 = soundPool.load(this, R.raw.endgame, 1)

        val backgroundMediaPlayer = MediaPlayer.create(this, R.raw.tgm_battle_bgm)
        backgroundMediaPlayer.isLooping = true
        backgroundMediaPlayer.start()

        val totalTime = 31000
        val interval = 1000

        val countDownTimer = object : CountDownTimer(totalTime.toLong(), interval.toLong()) {
            override fun onTick(millisUntilFinished: Long) {
                val timeLeft = millisUntilFinished / 1000
                time.text = "$timeLeft s"
            }

            override fun onFinish() {
                backgroundMediaPlayer.release()
                soundPool.play(soundCue3, 1f, 1f, 0, 0, 1f)
                supportActionBar?.hide()
                Handler(Looper.getMainLooper()).postDelayed({
                    val intent = Intent(this@MatchingGame, Endgame::class.java)
                    finish()
                    startActivity(intent)
                }, 250)
            }
        }
        countDownTimer.start()

        binding.back.setOnClickListener() {
            intent = Intent(this@MatchingGame, HomeMenu::class.java)
            startActivity(intent)
            this.finish()
            backgroundMediaPlayer.release()
        }
    }

    private fun placeDeck(){
        val images = mutableListOf(R.drawable.angelo_front,R.drawable.pauline_front,R.drawable.irish_front,
            R.drawable.paula_front, R.drawable.piplup_front, R.drawable.togepi_front)
        images.addAll(images)
        images.shuffle()

        buttons = listOf(binding.imageButton1,binding.imageButton2,
            binding.imageButton3,binding.imageButton4,binding.imageButton5,
            binding.imageButton6,binding.imageButton7,binding.imageButton8,
            binding.imageButton9,binding.imageButton10,binding.imageButton11,
            binding.imageButton12)

        cards = buttons.indices.map { index ->
            MemoryCard(images[index])
        }

        buttons.forEachIndexed { index, button ->
            button.setOnClickListener(){
                updateModels(index)
                updateViews()
            }
        }
    }

    private fun updateViews() {
        cards.forEachIndexed { index, card ->
            val button = buttons[index]
            button.setImageResource(if (card.isFaceUp) card.identifier else R.drawable.card_likod)
        }

    }

    private fun updateModels(position: Int) {
        val card = cards[position]
        if (card.isFaceUp) {
            //Toast.makeText(this, "Invalid move!", Toast.LENGTH_SHORT).show()
            return
        }
        if (indexOfSingleSelectedCard == null) {
            restoreCards()
            indexOfSingleSelectedCard = position
        } else {
            checkForMatch(indexOfSingleSelectedCard!!, position)
            indexOfSingleSelectedCard = null
        }
        card.isFaceUp = !card.isFaceUp
    }

    private fun restoreCards() {
        for (card in cards) {
            if (!card.isMatched) {
                card.isFaceUp = false
            }
        }
    }

    private fun checkForMatch(pos1: Int, pos2: Int) {
        if (cards[pos1].identifier == cards[pos2].identifier) {
            //Toast.makeText(this, "Matched!", Toast.LENGTH_SHORT).show()
            cards[pos1].isMatched = true
            cards[pos2].isMatched = true
            incrementScore()
            soundPool.play(soundCue1, 1f, 1f, 0, 0, 1f)
        }
        else {
            //Toast.makeText(this, "Not a match! Try again.", Toast.LENGTH_SHORT).show()
            cards[pos1].isFaceUp = false
            cards[pos2].isFaceUp = false
            soundPool.play(soundCue2, 1f, 1f, 0, 0, 1f)
        }
    }

    fun incrementScore() {
        val currentScore = score.text.toString()
        val incrementedScore = currentScore.toInt() + 100
        val targetScores = intArrayOf(600, 1200, 1800, 2400, 3000, 3600, 4200, 4800)

        score.text = incrementedScore.toString()
        if (targetScores.contains(score.text.toString().toInt())) {
            indexOfSingleSelectedCard = null
            placeDeck()
        }
    }
}
